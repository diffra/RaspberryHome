﻿<?php
  
/*
*   +------------------------------------------------------------------------------+
*       SERVER STATUS SCRIPT                                                               
*   +------------------------------------------------------------------------------+
*/ 
function microtime_float()
{
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}
$time_start = microtime_float();

$_ip = gethostbyname('drakerui.no-ip.biz');

//Setup Service Checks
$services = Array(
	Array("80", "Internet Connection", "google.com"),
	Array("80", "HTTP (Hyper Text Transfer Protocol)", ""),
	Array("443", "HTTPS (Secure Hyper Text Transfer Protocol)", ""),
	Array("22", "SSH (Secure Shell)", ""),
	Array("9091", "Transmission", "")
);

//Generate Service table
$data0 = "";
foreach ($services as $service) {
	$status = "offline";
	if(is_numeric($service[0])){
		if($service[2]==""){
			$service[2] = "localhost";
		}

		$fp = @fsockopen("$service[2]", $service[0], $errno, $errstr, 1);
								
		if ($fp) {
			$status = "online";
			fclose($fp);
		}
					
		@fclose($fp);
	} else{
		exec("pgrep $service[0]", $output, $return);
						
		if ($return == 0) {
			$status = "online";
		}
	}
	
	$data0 .= "<tr><td>$service[1]</td><td class='status-$status'>$status</td></tr>"; //'#FFC6C6' '#D9FFB3'
}


//GET SERVER LOADS
$loadresult = @exec('uptime'); 
preg_match("/averages?: ([0-9\.]+),[\s]+([0-9\.]+),[\s]+([0-9\.]+)/",$loadresult,$avgs);


//GET SERVER UPTIME
  $uptime = explode(' up ', $loadresult);
  $uptime = explode(',', $uptime[1]);
  $uptime = $uptime[0].', '.$uptime[1];

$data1 = "<tr><td>Server Load Averages </td><td>$avgs[1], $avgs[2], $avgs[3]</td>\n";
$data1 .= "<tr><td>Server Uptime</td><td>".$uptime."</td></tr>\n";  
  
//GET MEMORY DATA
  $free = `free -m | grep "buffers/cache" | awk '{print $4}'`;
  $usedram = chop(`free -m | grep Mem | awk '{print $3}'`);
  $totalram = chop(`free -m | grep Mem | awk '{print $2}'`);
  $usedram_percent = round($usedram*100/$totalram);

$data1 .= "<tr><td>Server Memory	</td><td>$usedram_percent% (".$usedram."MB/".$totalram."MB)</td></tr>\n";

$rootfs = chop(`df -h | grep rootfs | awk '{ print $5}'`);
$rootfssize = chop(`df -h | grep rootfs | awk '{print $2}'`);
$rootfsused = chop(`df -h | grep rootfs | awk '{print $3}'`);
$data1 .= "<tr><td>SD Card	</td><td>$rootfs ($rootfsused/$rootfssize)</td></tr>\n";

$mediafs = chop(`df -h | grep sda1 | awk '{ print $5}'`);
$mediafssize = chop(`df -h | grep sda1 | awk '{print $2}'`);
$mediafsused = chop(`df -h | grep sda1 | awk '{print $3}'`);
$data1 .= "<tr><td>Hard Disk	</td><td>$mediafs ($mediafsused/$mediafssize)</td></tr>\n";

  
//get ps data
  $ps = (`ps aux | wc -l`)-1;

$data1 .= "<tr><td>Server processes	</td><td>$ps Processes</td></tr>\n";  
  
//Get network connection total
$numtcp = `netstat -nt | grep tcp | wc -l`;
$numudp = `netstat -nu | grep udp | wc -l`;

$data1 .= "<tr><td>Open Connections	</td><td>TCP: $numtcp\tUDP: $numudp</td></tr>\n";

$cputemp= `cat /sys/class/thermal/thermal_zone0/temp`;
$cputemp= round(($cputemp/1000), 1);
$data1 .= "<tr><td>CPU Temp	</td><td>$cputemp &deg;C</td></tr>\n";

$gputemp= `/opt/vc/bin/vcgencmd measure_temp | sed 's/temp=//' | sed 's/.C//'`;
$gputemp= round(($gputemp), 1);
$data1 .= "<tr><td>GPU Temp	</td><td>$gputemp &deg;C</td></tr>\n";
?>
<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

    <!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<title>Raspberry Homepage</title>
	<meta name="description" content="Free Html5 Templates and Free Responsive Themes Designed by Kimmy | zerotheme.com">
	<meta name="author" content="www.zerotheme.com">
	
    <!-- Mobile Specific Metas
  ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- CSS
  ================================================== -->
	<link rel="stylesheet" href="css/zerogrid.css">
	<link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
	
	<!--[if lt IE 8]>
       <div style=' clear: both; text-align:center; position: relative;'>
         <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
           <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
      </div>
    <![endif]-->
    <!--[if lt IE 9]>
		<script src="js/html5.js"></script>
		<script src="js/css3-mediaqueries.js"></script>
	<![endif]-->
	
	<link href='./images/favicon.png' rel='icon' type='image/x-icon'/>    
</head>
<body>
<!--------------Header--------------->
<div class="wrap-header">
<header> 
	<div id="logo"><a href="#"><img src="./images/logo.png"/></a></div>
	
	<nav>
		<ul>
			<li class="current"><a href="#">Home</a></li>
			<li><a href="/transmission">Transmission</a></li>
			<li><a href="/control">Raspcontrol</a></li>
		</ul>
	</nav>
</header>
</div>
			
<!--------------Content--------------->
<section id="content">
	<div class="zerogrid">		
		<div class="row">
			<div id="main-content">
				<article>
					<div class="heading">
						<h2>Service Status</h2>
					</div>
					<div class="content">
						<table style="width:500px;">
							<tr><th>Service</th><th>Status</th></tr>
							<?php
								echo $data0;
							?>
						</table>
					</div>
				</article>
				<article>
					<div class="heading">
						<h2>System Status</h2>
					</div>
					<div class="content">
						<table style="width:500px;">
						<tr><th /><th /></tr>
						<?php
							echo $data1;
						?>
						</table>
					</div>
				</article>
			</div>
		</div>
	</div>
</section>
<!--------------Footer--------------->
<div class="wrap-footer">
	<footer>
		<div class="wrapfooter">
			<p>Page generated in <?php echo round(microtime_float() - $time_start, 1); ?> seconds</p>
		</div>
	</footer>
</div>
</body></html>
